from Swiat import Swiat


class Main:
    swiat = Swiat(10, 10)
    swiat.rysujSwiat()
