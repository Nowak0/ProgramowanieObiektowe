package swiat;


public class Main {
    public static void main(String[] args) {
        Swiat swiat = new Swiat(20,20);
        swiat.rysujSwiat();
    }
}
